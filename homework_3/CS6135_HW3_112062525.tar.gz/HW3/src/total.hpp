#ifndef TOTAL_HPP
#define TOTAL_HPP

#include <bits/stdc++.h>
#include "input.hpp"
#include "Floorplan.hpp"


// Ai <= (Hi / Wi) <= Bi
#define RATIO_Ai 0.5
#define RATIO_Bi 2.0

#endif